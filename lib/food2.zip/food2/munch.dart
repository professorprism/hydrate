// munch.dart
// Barrett Koster 2025
// This is for ONE item, something you ate
// and when you ate it, presumably.

// import "package:flutter/material.dart";

class Munch
{
  String what;

  String when;
  // int when;
  // DateTime when;

  Munch( this.what, this.when );
  // Munch( this.what, String whenString )
  // : when = DateTime.parse(whenString);
}

